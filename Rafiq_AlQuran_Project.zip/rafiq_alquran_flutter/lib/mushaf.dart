import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

const _green = Color(0xFF155746);
const _gold = Color(0xFFB88A38);
const _cream = Color(0xFFFAF6EA);

const quranAsset = 'assets/quran/quran-uthmani.txt';

const surahNames = [
  'الفاتحة', 'البقرة', 'آل عمران', 'النساء', 'المائدة', 'الأنعام', 'الأعراف', 'الأنفال', 'التوبة', 'يونس',
  'هود', 'يوسف', 'الرعد', 'إبراهيم', 'الحجر', 'النحل', 'الإسراء', 'الكهف', 'مريم', 'طه',
  'الأنبياء', 'الحج', 'المؤمنون', 'النور', 'الفرقان', 'الشعراء', 'النمل', 'القصص', 'العنكبوت', 'الروم',
  'لقمان', 'السجدة', 'الأحزاب', 'سبأ', 'فاطر', 'يس', 'الصافات', 'ص', 'الزمر', 'غافر',
  'فصلت', 'الشورى', 'الزخرف', 'الدخان', 'الجاثية', 'الأحقاف', 'محمد', 'الفتح', 'الحجرات', 'ق',
  'الذاريات', 'الطور', 'النجم', 'القمر', 'الرحمن', 'الواقعة', 'الحديد', 'المجادلة', 'الحشر', 'الممتحنة',
  'الصف', 'الجمعة', 'المنافقون', 'التغابن', 'الطلاق', 'التحريم', 'الملك', 'القلم', 'الحاقة', 'المعارج',
  'نوح', 'الجن', 'المزمل', 'المدثر', 'القيامة', 'الإنسان', 'المرسلات', 'النبأ', 'النازعات', 'عبس',
  'التكوير', 'الانفطار', 'المطففين', 'الانشقاق', 'البروج', 'الطارق', 'الأعلى', 'الغاشية', 'الفجر', 'البلد',
  'الشمس', 'الليل', 'الضحى', 'الشرح', 'التين', 'العلق', 'القدر', 'البينة', 'الزلزلة', 'العاديات',
  'القارعة', 'التكاثر', 'العصر', 'الهمزة', 'الفيل', 'قريش', 'الماعون', 'الكوثر', 'الكافرون', 'النصر',
  'المسد', 'الإخلاص', 'الفلق', 'الناس',
];

// بداية كل جزء: [رقم السورة، رقم الآية]
const _juzStarts = [
  [1, 1], [2, 142], [2, 253], [3, 93], [4, 24], [4, 148], [5, 82], [6, 111], [7, 88], [8, 41],
  [9, 93], [11, 6], [12, 53], [15, 1], [17, 1], [18, 75], [21, 1], [23, 1], [25, 21], [27, 56],
  [29, 46], [33, 31], [36, 28], [39, 32], [41, 47], [46, 1], [51, 31], [58, 1], [67, 1], [78, 1],
];

String _ar(int n) => n.toString().split('').map((c) => String.fromCharCode(0x0660 + int.parse(c))).join();

class Ayah {
  final int sura, aya;
  final String text;
  const Ayah(this.sura, this.aya, this.text);
}

class QuranData {
  final List<Ayah> ayahs;
  final List<int> counts = List<int>.filled(115, 0);
  QuranData(this.ayahs) {
    for (final a in ayahs) {
      if (a.sura >= 1 && a.sura <= 114) counts[a.sura]++;
    }
  }

  static QuranData? _cache;

  /// يقرأ ملف Tanzil بصيغة: رقم السورة|رقم الآية|النص (بدون أي تعديل على النص).
  static Future<QuranData?> load() async {
    if (_cache != null) return _cache;
    try {
      final raw = (await rootBundle.loadString(quranAsset)).replaceFirst('\uFEFF', '');
      final list = <Ayah>[];
      for (final line in raw.split('\n')) {
        final l = line.trim();
        if (l.isEmpty || l.startsWith('#')) continue;
        final a = l.indexOf('|');
        if (a < 0) continue;
        final b = l.indexOf('|', a + 1);
        if (b < 0) continue;
        final s = int.tryParse(l.substring(0, a));
        final y = int.tryParse(l.substring(a + 1, b));
        if (s == null || y == null) continue;
        list.add(Ayah(s, y, l.substring(b + 1)));
      }
      if (list.length != 6236) return null; // الملف ناقص أو بصيغة مختلفة
      _cache = QuranData(list);
      return _cache;
    } catch (_) {
      return null;
    }
  }

  int indexOf(int sura, int aya) => ayahs.indexWhere((a) => a.sura == sura && a.aya == aya);

  List<Ayah> surah(int n) => ayahs.where((a) => a.sura == n).toList();

  List<Ayah> juz(int n) {
    final s = _juzStarts[n - 1];
    final start = indexOf(s[0], s[1]);
    final end = n < 30 ? indexOf(_juzStarts[n][0], _juzStarts[n][1]) : ayahs.length;
    if (start < 0 || end < 0 || end <= start) return [];
    return ayahs.sublist(start, end);
  }
}

class MushafTab extends StatefulWidget {
  const MushafTab({super.key});
  @override
  State<MushafTab> createState() => _MushafTabState();
}

class _MushafTabState extends State<MushafTab> {
  QuranData? data;
  bool loading = true;
  bool byJuz = false;
  int lastSura = 0, lastAya = 0;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final d = await QuranData.load();
    await _loadLast();
    if (!mounted) return;
    setState(() {
      data = d;
      loading = false;
    });
  }

  Future<void> _loadLast() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      lastSura = p.getInt('lastSura') ?? 0;
      lastAya = p.getInt('lastAya') ?? 0;
    });
  }

  Future<void> _open(String title, List<Ayah> ayahs, {int focusSura = 0, int focusAya = 0}) async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ReaderPage(title: title, ayahs: ayahs, focusSura: focusSura, focusAya: focusAya)),
    );
    await _loadLast();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    final d = data;
    if (d == null) return _missing();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Column(children: [
          if (lastSura > 0)
            Card(
              child: ListTile(
                leading: const CircleAvatar(backgroundColor: Color(0xFFE1EFE7), child: Icon(Icons.bookmark, color: _green)),
                title: const Text('متابعة القراءة'),
                subtitle: Text('سورة ${surahNames[lastSura - 1]} • الآية $lastAya'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => _open('سورة ${surahNames[lastSura - 1]}', d.surah(lastSura), focusSura: lastSura, focusAya: lastAya),
              ),
            ),
          const SizedBox(height: 4),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('السور')),
              ButtonSegment(value: true, label: Text('الأجزاء')),
            ],
            selected: {byJuz},
            onSelectionChanged: (s) => setState(() => byJuz = s.first),
          ),
        ]),
      ),
      Expanded(
        child: ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          itemCount: byJuz ? 30 : 114,
          itemBuilder: (ctx, i) {
            if (byJuz) {
              return Card(
                child: ListTile(
                  leading: CircleAvatar(backgroundColor: const Color(0xFFF6EBD4), child: Text(_ar(i + 1), style: const TextStyle(color: _gold, fontWeight: FontWeight.bold))),
                  title: Text('الجزء ${_ar(i + 1)}'),
                  subtitle: Text('يبدأ من سورة ${surahNames[_juzStarts[i][0] - 1]} آية ${_juzStarts[i][1]}'),
                  onTap: () => _open('الجزء ${_ar(i + 1)}', d.juz(i + 1)),
                ),
              );
            }
            return Card(
              child: ListTile(
                leading: CircleAvatar(backgroundColor: const Color(0xFFE1EFE7), child: Text(_ar(i + 1), style: const TextStyle(color: _green, fontWeight: FontWeight.bold, fontSize: 13))),
                title: Text('سورة ${surahNames[i]}'),
                subtitle: Text('${d.counts[i + 1]} آية'),
                onTap: () => _open('سورة ${surahNames[i]}', d.surah(i + 1)),
              ),
            );
          },
        ),
      ),
      const Padding(
        padding: EdgeInsets.all(8),
        child: Text('نص المصحف: مشروع تنزيل Tanzil.net (رواية حفص، الرسم العثماني) — رخصة CC BY 3.0 — منقول دون تعديل.',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black54)),
      ),
    ]);
  }

  Widget _missing() => ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: const Color(0xFFE8F0E6), borderRadius: BorderRadius.circular(20)),
          child: const Column(children: [
            Icon(Icons.menu_book_rounded, size: 64, color: _green),
            SizedBox(height: 12),
            Text('المصحف الكامل دون إنترنت', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: _green)),
            SizedBox(height: 8),
            Text('لم يُضَف ملف نص المصحف إلى هذه النسخة بعد.\nحمّلي ملف Tanzil (الرسم العثماني، بصيغة «Text with aya numbers») وضعيه باسم quran-uthmani.txt داخل assets/quran/ ثم أعيدي بناء التطبيق.',
                textAlign: TextAlign.center, style: TextStyle(height: 1.6)),
          ]),
        ),
      ]);
}

class ReaderPage extends StatefulWidget {
  final String title;
  final List<Ayah> ayahs;
  final int focusSura, focusAya;
  const ReaderPage({super.key, required this.title, required this.ayahs, this.focusSura = 0, this.focusAya = 0});
  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  double fontSize = 26;
  int start = 0;
  int markSura = 0, markAya = 0;
  SharedPreferences? prefs;

  @override
  void initState() {
    super.initState();
    markSura = widget.focusSura;
    markAya = widget.focusAya;
    final idx = widget.ayahs.indexWhere((a) => a.sura == widget.focusSura && a.aya == widget.focusAya);
    start = idx > 0 ? idx : 0;
    _initPrefs();
  }

  Future<void> _initPrefs() async {
    final p = await SharedPreferences.getInstance();
    prefs = p;
    if (!mounted) return;
    setState(() => fontSize = p.getDouble('fontSize') ?? 26);
  }

  void _setFont(double v) {
    final size = v.clamp(18.0, 44.0).toDouble();
    setState(() => fontSize = size);
    prefs?.setDouble('fontSize', size);
  }

  void _mark(Ayah a) {
    setState(() {
      markSura = a.sura;
      markAya = a.aya;
    });
    prefs?.setInt('lastSura', a.sura);
    prefs?.setInt('lastAya', a.aya);
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(duration: const Duration(seconds: 1), content: Text('تم حفظ موضع القراءة: ${surahNames[a.sura - 1]} • ${a.aya}')));
  }

  @override
  Widget build(BuildContext context) {
    final extra = start > 0 ? 1 : 0;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(tooltip: 'تصغير الخط', onPressed: () => _setFont(fontSize - 2), icon: const Icon(Icons.text_decrease)),
          IconButton(tooltip: 'تكبير الخط', onPressed: () => _setFont(fontSize + 2), icon: const Icon(Icons.text_increase)),
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          const Padding(
            padding: EdgeInsets.all(6),
            child: Text('اضغطي على الآية لحفظ موضع القراءة', style: TextStyle(fontSize: 12, color: Colors.black54)),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              itemCount: widget.ayahs.length - start + extra,
              itemBuilder: (ctx, i) {
                if (extra == 1) {
                  if (i == 0) {
                    return TextButton(onPressed: () => setState(() => start = 0), child: const Text('عرض ما قبل هذا الموضع'));
                  }
                  i -= 1;
                }
                final a = widget.ayahs[start + i];
                final marked = a.sura == markSura && a.aya == markAya;
                final tile = InkWell(
                  onTap: () => _mark(a),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(color: marked ? const Color(0xFFF6EBD4) : null, borderRadius: BorderRadius.circular(12)),
                    child: Text('${a.text} \uFD3F${_ar(a.aya)}\uFD3E', style: TextStyle(fontSize: fontSize, height: 2.0)),
                  ),
                );
                if (a.aya != 1) return tile;
                return Column(children: [
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(14)),
                    child: Text('سورة ${surahNames[a.sura - 1]}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                  tile,
                ]);
              },
            ),
          ),
        ]),
      ),
      backgroundColor: _cream,
    );
  }
}
