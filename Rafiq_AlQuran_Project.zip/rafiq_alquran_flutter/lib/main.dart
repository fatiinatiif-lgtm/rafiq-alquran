import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF155746);
const gold = Color(0xFFB88A38);
const cream = Color(0xFFFAF6EA);
const purple = Color(0xFF7764A5);
const blue = Color(0xFF477DA8);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RafiqApp());
}

class RafiqApp extends StatelessWidget {
  const RafiqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'رفيق القرآن',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        appBarTheme: const AppBarTheme(
          backgroundColor: green, foregroundColor: Colors.white, centerTitle: true,
        ),
        fontFamily: 'Roboto',
        cardTheme: CardThemeData(
          color: Colors.white, elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE7DCC5)),
          ),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  int readPart = 1, readHizb = 1, memPart = 1, memHizb = 1;
  int readDone = 0, memDone = 0;
  List<String> reviews = [];
  List<String> history = [];
  late SharedPreferences prefs;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      readPart = prefs.getInt('readPart') ?? 1;
      readHizb = prefs.getInt('readHizb') ?? 1;
      memPart = prefs.getInt('memPart') ?? 1;
      memHizb = prefs.getInt('memHizb') ?? 1;
      readDone = prefs.getInt('readDone') ?? 0;
      memDone = prefs.getInt('memDone') ?? 0;
      reviews = prefs.getStringList('reviews') ?? [];
      history = prefs.getStringList('history') ?? [];
    });
  }

  Future<void> _save() async {
    await prefs.setInt('readPart', readPart);
    await prefs.setInt('readHizb', readHizb);
    await prefs.setInt('memPart', memPart);
    await prefs.setInt('memHizb', memHizb);
    await prefs.setInt('readDone', readDone);
    await prefs.setInt('memDone', memDone);
    await prefs.setStringList('reviews', reviews);
    await prefs.setStringList('history', history);
  }

  void _record(String kind, String detail) {
    final now = DateTime.now();
    final date = '${now.year}/${now.month.toString().padLeft(2, '0')}/${now.day.toString().padLeft(2, '0')}';
    history.insert(0, '$date • $kind: $detail');
    if (history.length > 100) history = history.take(100).toList();
    _save();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _reading(),
      _memorization(),
      _reviews(),
      _mushaf(),
      _stats(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('رفيق القرآن', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: () => setState(() => tab = 5), icon: const Icon(Icons.insights))],
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab > 4 ? 5 : tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'القراءة'),
          NavigationDestination(icon: Icon(Icons.psychology_alt_outlined), selectedIcon: Icon(Icons.psychology_alt), label: 'الحفظ'),
          NavigationDestination(icon: Icon(Icons.refresh), label: 'المراجعة'),
          NavigationDestination(icon: Icon(Icons.auto_stories_outlined), label: 'المصحف'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'إحصائيات'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [green, Color(0xFF287861)]),
          borderRadius: BorderRadius.circular(24),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(Icons.menu_book_rounded, color: Color(0xFFE8C77D), size: 42),
          SizedBox(height: 12),
          Text('وَرْدُك اليومي، خطوة نحو الإتقان', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('اللهم اجعل القرآن ربيع قلوبنا', style: TextStyle(color: Colors.white70, fontSize: 15)),
        ]),
      ),
      const SizedBox(height: 18),
      Text('إنجاز اليوم', style: _heading()),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _summary('القراءة', '$readDone / 1', Icons.menu_book, green, () => setState(() => tab = 1))),
        const SizedBox(width: 8),
        Expanded(child: _summary('الحفظ', '$memDone / 1', Icons.psychology_alt, gold, () => setState(() => tab = 2))),
        const SizedBox(width: 8),
        Expanded(child: _summary('المراجعة', '${reviews.length}', Icons.refresh, purple, () => setState(() => tab = 3))),
      ]),
      const SizedBox(height: 18),
      Text('ورد القراءة اليومي', style: _heading()),
      Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFE1EFE7), child: Icon(Icons.menu_book, color: green)),
        title: Text('الجزء $readPart • الحزب $readHizb'),
        subtitle: Text(readDone == 1 ? 'تم تسجيل إنجاز القراءة اليوم' : 'لم تسجلي إنجاز القراءة اليوم بعد'),
        trailing: IconButton(icon: const Icon(Icons.arrow_forward_ios), onPressed: () => setState(() => tab = 1)),
      )),
      Text('الحفظ الجديد', style: _heading()),
      Card(child: ListTile(
        leading: const CircleAvatar(backgroundColor: Color(0xFFF6EBD4), child: Icon(Icons.psychology_alt, color: gold)),
        title: Text('الجزء $memPart • الحزب $memHizb'),
        subtitle: Text(memDone == 1 ? 'تم تسجيل إنجاز الحفظ اليوم' : 'حددي ورد الحفظ وابدئي'),
        trailing: IconButton(icon: const Icon(Icons.arrow_forward_ios), onPressed: () => setState(() => tab = 2)),
      )),
      const SizedBox(height: 12),
      const Text('تُحفظ بيانات المتابعة على هذا الجهاز. محتوى المصحف الكامل سيُضاف بعد توفير ملف قرآن موثوق ومراجع.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.5)),
    ],
  );

  Widget _summary(String title, String value, IconData icon, Color color, VoidCallback onTap) => InkWell(
    onTap: onTap,
    child: Card(child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 6),
      child: Column(children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 8),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 4),
        Text(title, style: const TextStyle(fontSize: 12)),
      ]),
    )),
  );

  Widget _reading() => ListView(padding: const EdgeInsets.all(16), children: [
    _pageTitle('القراءة اليومية', Icons.menu_book, green),
    const Text('اختاري الجزء والحزب اللذين ستقرئينهما اليوم.', textAlign: TextAlign.center),
    const SizedBox(height: 16),
    _numberPicker('الجزء', readPart, 30, (v) { setState(() => readPart = v); _save(); }),
    _numberPicker('الحزب', readHizb, 60, (v) { setState(() => readHizb = v); _save(); }),
    const SizedBox(height: 12),
    Card(child: const Padding(padding: EdgeInsets.all(14), child: Text('يمكنك تسجيل ورد القراءة على مستوى الجزء أو الحزب. أضيفي لاحقًا تفاصيل الصفحات إذا رغبتِ.', textAlign: TextAlign.center))),
    FilledButton.icon(
      style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.all(16)),
      onPressed: () { setState(() => readDone = 1); _record('القراءة', 'الجزء $readPart، الحزب $readHizb'); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل إنجاز القراءة'))); },
      icon: const Icon(Icons.check_circle_outline), label: const Text('تسجيل إتمام ورد القراءة'),
    ),
    OutlinedButton(onPressed: () { setState(() => readDone = 0); _save(); }, child: const Text('إلغاء علامة الإتمام')),
  ]);

  Widget _memorization() => ListView(padding: const EdgeInsets.all(16), children: [
    _pageTitle('الحفظ الجديد', Icons.psychology_alt, gold),
    const Text('حددي الجزء والحزب المخصصين للحفظ الجديد.', textAlign: TextAlign.center),
    const SizedBox(height: 16),
    _numberPicker('الجزء', memPart, 30, (v) { setState(() => memPart = v); _save(); }),
    _numberPicker('الحزب', memHizb, 60, (v) { setState(() => memHizb = v); _save(); }),
    Card(child: const Padding(padding: EdgeInsets.all(14), child: Text('نصيحة: اجعلي المقدار مناسبًا لوقتك، وراجعي ما حفظتِ قبل الانتقال إلى مقدار جديد.', textAlign: TextAlign.center))),
    FilledButton.icon(
      style: FilledButton.styleFrom(backgroundColor: gold, padding: const EdgeInsets.all(16)),
      onPressed: () { setState(() => memDone = 1); _record('الحفظ الجديد', 'الجزء $memPart، الحزب $memHizb'); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل إنجاز الحفظ'))); },
      icon: const Icon(Icons.check_circle_outline), label: const Text('تسجيل إتمام ورد الحفظ'),
    ),
    OutlinedButton(onPressed: () { setState(() => memDone = 0); _save(); }, child: const Text('إلغاء علامة الإتمام')),
  ]);

  Widget _reviews() => ListView(padding: const EdgeInsets.all(16), children: [
    _pageTitle('مراجعة التثبيت', Icons.refresh, purple),
    const Text('أضيفي بنفسك ما تريدين مراجعته، ثم علّميه عند الانتهاء.', textAlign: TextAlign.center),
    const SizedBox(height: 16),
    FilledButton.icon(
      style: FilledButton.styleFrom(backgroundColor: purple, padding: const EdgeInsets.all(15)),
      onPressed: _addReview, icon: const Icon(Icons.add), label: const Text('إضافة مراجعة جديدة'),
    ),
    const SizedBox(height: 12),
    if (reviews.isEmpty)
      const Card(child: Padding(padding: EdgeInsets.all(24), child: Column(children: [
        Icon(Icons.auto_stories, color: purple, size: 42),
        SizedBox(height: 8),
        Text('لا توجد مراجعات بعد'),
        Text('اضغطي «إضافة مراجعة جديدة» لبدء خطتك.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
      ])))
    else
      ...reviews.asMap().entries.map((e) => Card(child: ListTile(
        leading: const Icon(Icons.bookmark_outline, color: purple),
        title: Text(e.value),
        trailing: IconButton(icon: const Icon(Icons.check_circle_outline), tooltip: 'تمت المراجعة', onPressed: () { setState(() { reviews.removeAt(e.key); }); _record('مراجعة مكتملة', e.value); _save(); }),
        onLongPress: () { setState(() => reviews.removeAt(e.key)); _save(); },
      ))),
  ]);

  Future<void> _addReview() async {
    final controller = TextEditingController();
    final value = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('إضافة مراجعة'),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'مثال: سورة البقرة، من آية ...')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('إضافة')),
      ],
    ));
    if (value != null && value.isNotEmpty) {
      setState(() => reviews.add(value));
      await _save();
    }
  }

  Widget _mushaf() => ListView(padding: const EdgeInsets.all(16), children: [
    _pageTitle('المصحف الشريف', Icons.auto_stories, green),
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(color: const Color(0xFFE8F0E6), borderRadius: BorderRadius.circular(20)),
      child: const Column(children: [
        Icon(Icons.menu_book_rounded, size: 64, color: green),
        SizedBox(height: 12),
        Text('المصحف الكامل دون إنترنت', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: green)),
        SizedBox(height: 8),
        Text('هذه نسخة أولية من الشاشة. لم يُضمَّن نص القرآن بعد، حتى نضيف مصدرًا موثوقًا ومراجعًا للنص القرآني.', textAlign: TextAlign.center, style: TextStyle(height: 1.5)),
      ]),
    ),
    const SizedBox(height: 16),
    const Text('سيُضاف في الخطوة التالية:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    const ListTile(leading: Icon(Icons.check_circle, color: green), title: Text('نص القرآن كاملًا مع التشكيل')),
    const ListTile(leading: Icon(Icons.check_circle, color: green), title: Text('التنقل بين السور والأجزاء والأحزاب')),
    const ListTile(leading: Icon(Icons.check_circle, color: green), title: Text('حفظ آخر موضع قراءة دون إنترنت')),
  ]);

  Widget _stats() => ListView(padding: const EdgeInsets.all(16), children: [
    _pageTitle('إحصائياتي وسجل الإنجاز', Icons.bar_chart, blue),
    Row(children: [
      Expanded(child: _statCard('أيام القراءة المسجلة', '$readDone', green, Icons.menu_book)),
      const SizedBox(width: 8),
      Expanded(child: _statCard('أيام الحفظ المسجلة', '$memDone', gold, Icons.psychology_alt)),
    ]),
    Card(child: ListTile(leading: const Icon(Icons.refresh, color: purple), title: const Text('المراجعات الحالية'), trailing: Text('${reviews.length}'))),
    const SizedBox(height: 12),
    Text('سجل الإنجاز', style: _heading()),
    if (history.isEmpty)
      const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('سيظهر هنا سجل إنجازاتك عند تسجيل القراءة أو الحفظ أو إتمام المراجعات.', textAlign: TextAlign.center)))
    else
      ...history.map((item) => Card(child: ListTile(leading: const Icon(Icons.history, color: blue), title: Text(item)))),
    TextButton.icon(onPressed: () async { setState(() => history.clear()); await _save(); }, icon: const Icon(Icons.delete_outline), label: const Text('مسح سجل الإنجاز')),
  ]);

  Widget _statCard(String label, String value, Color color, IconData icon) => Card(child: Padding(
    padding: const EdgeInsets.all(16), child: Column(children: [
      Icon(icon, color: color, size: 30), const SizedBox(height: 8),
      Text(value, style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: color)),
      Text(label, textAlign: TextAlign.center),
    ]),
  ));

  Widget _pageTitle(String title, IconData icon, Color color) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(children: [
      Icon(icon, size: 42, color: color),
      const SizedBox(height: 8),
      Text(title, style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: color)),
      const SizedBox(height: 12),
    ]),
  );

  Widget _numberPicker(String label, int value, int max, ValueChanged<int> onChanged) => Card(
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: Row(children: [
        Expanded(child: Text(label, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600))),
        IconButton(onPressed: value > 1 ? () => onChanged(value - 1) : null, icon: const Icon(Icons.remove_circle_outline)),
        Container(width: 54, padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: cream, borderRadius: BorderRadius.circular(12)), child: Text('$value', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
        IconButton(onPressed: value < max ? () => onChanged(value + 1) : null, icon: const Icon(Icons.add_circle_outline)),
      ]),
    ),
  );

  TextStyle _heading() => const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: green);

}
