ضعي هنا ملف quran-uthmani.txt (من tanzil.net/download):
- Quran Text Type: Uthmani
- Output: Text (with aya numbers)  [صيغة: رقم السورة|رقم الآية|النص]
- لا تعدّلي النص (شرط رخصة CC BY 3.0). يجب أن يحتوي الملف على 6236 آية.
